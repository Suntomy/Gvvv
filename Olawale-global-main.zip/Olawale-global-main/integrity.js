/*
 * Global Pilgrim — Module Integrity Verifier
 * ------------------------------------------
 * Ported from the supplied Python allowlist module, with the security logic
 * CORRECTED. The original snippet logged "INTEGRITY: Hash match ... Deployment
 * unblock" when the hash did NOT match, and returned False. That is inverted:
 * a mismatch is the dangerous case and must block. This file does it properly:
 *
 *   hash matches allowlist  -> APPROVED (staged for admin approval)
 *   hash missing/mismatched -> REJECTED (deployment blocked, alert raised)
 *
 * Usage
 *   node integrity.js --generate        # write a manifest for the guarded files
 *   node integrity.js --verify          # verify every file against the manifest
 *   node integrity.js --verify path.js  # verify one file
 *
 * The manifest lives in module-hashes.json and is loaded at boot by server.js.
 * Nothing here runs in the browser: a browser check can be edited by the user,
 * so integrity must be enforced where the code actually executes.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MANIFEST_PATH = path.join(__dirname, 'module-hashes.json');

/* Modules that must never change without an explicit, reviewed manifest update. */
const GUARDED_MODULES = ['server.js', 'webhooks.js', 'integrity.js', 'schema.sql'];

function calculateSha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function loadManifest(file = MANIFEST_PATH) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    return raw && typeof raw.approved === 'object' ? raw : { approved: {} };
  } catch (err) {
    if (err.code === 'ENOENT') return { approved: {} };
    throw err;
  }
}

function saveManifest(manifest, file = MANIFEST_PATH) {
  fs.writeFileSync(file, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
}

/**
 * Verify a module buffer against the approved-hash allowlist.
 * Returns a result object; never throws for a plain mismatch.
 */
function verifyModule(name, buffer, manifest = loadManifest()) {
  const actual = calculateSha256(buffer);
  const expected = manifest.approved[name];

  if (!expected) {
    return {
      name,
      ok: false,
      status: 'UNLISTED',
      actual,
      expected: null,
      reason: 'module is not in the approved allowlist — deployment blocked'
    };
  }

  if (expected !== actual) {
    return {
      name,
      ok: false,
      status: 'TAMPERED',
      actual,
      expected,
      reason: 'SHA-256 mismatch — file differs from the approved build, deployment blocked'
    };
  }

  return { name, ok: true, status: 'APPROVED', actual, expected, reason: 'hash matches approved build' };
}

function verifyFile(name, manifest = loadManifest()) {
  const file = path.join(__dirname, name);
  if (!fs.existsSync(file)) {
    return { name, ok: false, status: 'MISSING', actual: null, expected: manifest.approved[name] || null, reason: 'file not found' };
  }
  return verifyModule(name, fs.readFileSync(file), manifest);
}

function verifyAll(manifest = loadManifest()) {
  const results = GUARDED_MODULES.map(n => verifyFile(n, manifest));
  return { ok: results.every(r => r.ok), results, checkedAt: new Date().toISOString() };
}

function generateManifest() {
  const approved = {};
  for (const name of GUARDED_MODULES) {
    const file = path.join(__dirname, name);
    if (fs.existsSync(file)) approved[name] = calculateSha256(fs.readFileSync(file));
  }
  return { algorithm: 'sha256', generatedAt: new Date().toISOString(), approved };
}

/**
 * Boot-time gate. In production (or when REQUIRE_INTEGRITY=true) a tampered
 * module stops the process instead of silently serving modified code.
 */
function assertIntegrity({ required = process.env.REQUIRE_INTEGRITY === 'true' || process.env.NODE_ENV === 'production', logger = console } = {}) {
  const report = verifyAll();
  if (!report.ok) {
    for (const r of report.results.filter(x => !x.ok)) {
      logger.error(`INTEGRITY ${r.status}: ${r.name} — ${r.reason}`);
    }
  }
  if (!report.ok && required) {
    const err = new Error('module integrity check failed — refusing to start');
    err.code = 'INTEGRITY_FAILED';
    err.report = report;
    throw err;
  }
  return report;
}

module.exports = {
  GUARDED_MODULES,
  MANIFEST_PATH,
  calculateSha256,
  loadManifest,
  saveManifest,
  verifyModule,
  verifyFile,
  verifyAll,
  generateManifest,
  assertIntegrity
};

/* ---- CLI ---- */
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.includes('--generate')) {
    const manifest = generateManifest();
    saveManifest(manifest);
    console.log(`Wrote ${MANIFEST_PATH}`);
    for (const [k, v] of Object.entries(manifest.approved)) console.log(`  ${v}  ${k}`);
  } else if (args.includes('--verify')) {
    const idx = args.indexOf('--verify');
    const target = args[idx + 1];
    const report = target && !target.startsWith('--')
      ? (() => { const r = verifyFile(target); return { ok: r.ok, results: [r] }; })()
      : verifyAll();
    for (const r of report.results) {
      console.log(`${r.ok ? 'APPROVED ' : 'REJECTED '} ${r.name.padEnd(14)} ${r.status.padEnd(9)} ${r.actual || '-'}`);
      if (!r.ok) console.log(`           ${r.reason}`);
    }
    process.exit(report.ok ? 0 : 1);
  } else {
    console.log('Usage: node integrity.js --generate | --verify [file]');
  }
}
