
<script>
async function startPayment(email, amountNaira) {
  try {
    const response = await fetch("http://localhost:3000/api/initialize-payment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, amount: amountNaira })
    });

    const result = await response.json();

    if (result.status && result.data?.authorization_url) {
      // Redirect customer to the official payment checkout page
      window.location.href = result.data.authorization_url;
    } else {
      console.error("Payment gateway error:", result);
    }
  } catch (err) {
    console.error("Network error calling payment backend:", err);
  }
}
</script>
<script> const fs = require("fs");
const path = require("path");

const root = process.cwd();

console.log("🥷 Configuring project for Console Ninja...\n");

// 1. Create .vscode/settings.json so Console Ninja auto-starts and captures all logs
const vscodeDir = path.join(root, ".vscode");
const settingsPath = path.join(vscodeDir, "settings.json");

if (!fs.existsSync(vscodeDir)) {
  fs.mkdirSync(vscodeDir, { recursive: true });
}

let existingSettings = {};
if (fs.existsSync(settingsPath)) {
  try {
    existingSettings = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
  } catch (e) {
    console.warn("⚠️ Could not parse existing .vscode/settings.json, skipping overwrite.");
  }
}

const ninjaSettings = {
  ...existingSettings,
  "console-ninja.featureSet": "Community",
  "console-ninja.captureFunctions": true,
  "console-ninja.showSingleLineLogs": true,
  "console-ninja.toolsToEnableSupportFor": {
    "live-server": true,
    "vite": true,
    "webpack": true,
    "nextjs": true,
    "nodejs": true
  }
};

fs.writeFileSync(settingsPath, JSON.stringify(ninjaSettings, null, 2));
console.log("✅ Configured .vscode/settings.json for Console Ninja.");

// 2. Ensure tsconfig.json (if present) generates source maps so Console Ninja maps errors to exact lines
const tsconfigPath = path.join(root, "tsconfig.json");
if (fs.existsSync(tsconfigPath)) {
  try {
    const tsconfig = JSON.parse(fs.readFileSync(tsconfigPath, "utf8"));
    tsconfig.compilerOptions = tsconfig.compilerOptions || {};
    tsconfig.compilerOptions.sourceMap = true;
    fs.writeFileSync(tsconfigPath, JSON.stringify(tsconfig, null, 2));
    console.log("Enabled sourceMap in tsconfig.json.");
  } catch (e) {
    console.warn(" Could not update tsconfig.json automatically (it may contain comments). Ensure \"sourceMap\": true is set.");
  }
}

// 3. Create a starter dev script in package.json if one is missing (needed for plain HTML/JS projects)
const pkgPath = path.join(root, "package.json");
if (!fs.existsSync(pkgPath)) {
  const defaultPkg = {
    name: "payment-app",
    version: "1.0.0",
    scripts: {
      dev: "npx live-server --port=3000"
    }
  };
  fs.writeFileSync(pkgPath, JSON.stringify(defaultPkg, null, 2));
  console.log("created package.json with 'npm run dev' (live-server) for plain HTML/JS files.");
} else {
  console.log("ℹ package.json already exists. Make sure you run your app with 'npm run dev' or 'node your-file.js'.");
}

// 4. Create a clean logger helper file you can import anywhere (optional)
const helperPath = path.join(root, "ninja-debug.js");
const helperCode = `// Optional helper: Import or include this in your HTML to trace payment steps in Console Ninja
window.ninjaTrace = function (step, data) {
  console.log(\`[PAYMENT STEP: \${step}]\`, data);
};
`;

if (!fs.existsSync(helperPath)) {
  fs.writeFileSync(helperPath, helperCode);
  console.log("Created ninja-debug.js helper for tracing payment steps.");
}

console.log("\n Done! Next steps:");
console.log("1. Make sure the 'Console Ninja' extension is installed in VS Code / Cursor.");
console.log("2. Start your app inside the editor terminal using: npm run dev");
console.log("3. Open http://localhost:3000 in your browser — logs and errors will now appear inline next to your code.");
}
</script>
<script>
{
const fs = require("fs");
const path = require("path");

const ROOT_DIR = process.cwd();
const IGNORED_DIRS = new Set(["node_modules", ".git", ".vscode", "dist", "build"]);

// Official Payment SDKs the robot can automatically inject if referenced in your code
const KNOWN_SDKS = [
  {
    name: "Paystack Inline SDK",
    detectPattern: /PaystackPop/i,
    scriptTag: '<script src="https://paystack.co"></script>'
  },
  {
    name: "Flutterwave V3 SDK",
    detectPattern: /FlutterwaveCheckout/i,
    scriptTag: '<script src="https://flutterwave.com"></script>'
  },
  {
    name: "Monnify SDK",
    detectPattern: /MonnifySDK/i,
    scriptTag: '<script src="https://monnify.com"></script>'
  },
  {
    name: "Stripe JS SDK",
    detectPattern: /Stripe\(/,
    scriptTag: '<script src="https://stripe.com"></script>'
  }
];

function getAllFiles(dir, fileList = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (IGNORED_DIRS.has(entry.name)) continue;
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      getAllFiles(fullPath, fileList);
    } else {
      fileList.push(fullPath);
    }
  }
  return fileList;
}

function runScriptRobot() {
  console.log("🤖 Script Robot scanning project for missing scripts...\n");

  const allFiles = getAllFiles(ROOT_DIR);
  const htmlFiles = allFiles.filter(f => f.endsWith(".html"));
  const jsFiles = allFiles.filter(f => f.endsWith(".js") && !f.endsWith("script-robot.js"));

  if (htmlFiles.length === 0) {
    console.log("⚠️ No HTML files found in this folder.");
    return;
  }

  for (const htmlFile of htmlFiles) {
    let htmlContent = fs.readFileSync(htmlFile, "utf8");
    const htmlDir = path.dirname(htmlFile);
    let modified = false;

    console.log(`📄 Inspecting: ${path.relative(ROOT_DIR, htmlFile)}`);

    // 1. Check all <script src="..."> tags in HTML for missing local JS files
    const scriptSrcRegex = /<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*><\/script>/gi;
    let match;
    while ((match = scriptSrcRegex.exec(htmlContent)) !== null) {
      const src = match[1];
      // Skip external URLs (http/https)
      if (/^https?:\/\//i.test(src) || src.startsWith("//")) continue;

      const cleanSrc = src.split("?")[0];
      const targetJsPath = path.resolve(htmlDir, cleanSrc);

      if (!fs.existsSync(targetJsPath)) {
        fs.mkdirSync(path.dirname(targetJsPath), { recursive: true });
        const starterCode = `// Auto-generated by Script Robot because it was referenced in ${path.basename(htmlFile)}\nconsole.log("✅ Loaded ${cleanSrc}");\n`;
        fs.writeFileSync(targetJsPath, starterCode);
        console.log(`   🛠️ Created missing local JS file: ${cleanSrc}`);
      }
    }

    // 2. Check if any external Payment SDK is used in the page or JS files, and inject <script> if missing
    const combinedCode =
      htmlContent +
      "\n" +
      jsFiles.map(f => fs.readFileSync(f, "utf8")).join("\n");

    for (const sdk of KNOWN_SDKS) {
      if (sdk.detectPattern.test(combinedCode) && !htmlContent.includes(sdk.scriptTag)) {
        if (htmlContent.includes("</head>")) {
          htmlContent = htmlContent.replace("</head>", `  ${sdk.scriptTag}\n</head>`);
        } else {
          htmlContent = `${sdk.scriptTag}\n` + htmlContent;
        }
        modified = true;
        console.log(`   💉 Injected missing ${sdk.name}`);
      }
    }

    // 3. Check for orphan local JS files in the same folder not linked in the HTML
    const siblingJsFiles = fs
      .readdirSync(htmlDir)
      .filter(f => f.endsWith(".js") && f !== "script-robot.js" && f !== "setup-console-ninja.js");

    for (const jsFileName of siblingJsFiles) {
      const linkRegex = new RegExp(`src=["'](\\.\\/)?${jsFileName}["']`, "i");
      if (!linkRegex.test(htmlContent)) {
        const tag = `<script src="./${jsFileName}"></script>`;
        if (htmlContent.includes("</body>")) {
          htmlContent = htmlContent.replace("</body>", `  ${tag}\n</body>`);
        } else {
          htmlContent += `\n${tag}\n`;
        }
        modified = true;
        console.log(`   🔗 Linked unattached script: ${jsFileName}`);
      }
    }

    if (modified) {
      fs.writeFileSync(htmlFile, htmlContent, "utf8");
      console.log(`   ✅ Saved updates to ${path.basename(htmlFile)}`);
    } else {
      console.log("   👍 All scripts already in place.");
    }
  }

  console.log("\n🎉 Script Robot finished! Check Console Ninja in your editor to verify everything loads cleanly.");
}

runScriptRobot();
}
</script>
<script> // check-my-wallets.js (Read-Only Public Balance Checker)
// Safe: Uses ONLY public wallet addresses. Never put private keys or seed phrases in scripts.

const MY_WALLETS = [
  // Replace these with YOUR OWN public addresses (0x...)
  "0x0000000000000000000000000000000000000000"
];

const NETWORKS = [
  { name: "Ethereum Mainnet", symbol: "ETH", rpc: "https://cloudflare-eth.com" },
  { name: "BNB Smart Chain", symbol: "BNB", rpc: "https://binance.org" },
  { name: "Polygon", symbol: "POL", rpc: "https://polygon-rpc.com" }
];

async function hasInternet() {
  try {
    const res = await fetch("https://cloudflare-eth.com", { method: "HEAD" });
    return res.ok || res.status < 500;
  } catch {
    return false;
  }
}

async function getNativeBalance(rpcUrl, address) {
  const response = await fetch(rpcUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      method: "eth_getBalance",
      params: [address, "latest"],
      id: 1
    })
  });

  const data = await response.json();
  if (!data.result) return "0";

  // Convert Wei (hex) to standard coin units
  const wei = BigInt(data.result);
  const whole = wei / 10n ** 18n;
  const fraction = (wei % 10n ** 18n).toString().padStart(18, "0").slice(0, 6);
  return `${whole}.${fraction}`;
}

async function checkWalletsWhenOnline() {
  console.log("🌐 Checking for internet connection...");

  while (!(await hasInternet())) {
    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  console.log("✅ Network connected. Checking your public wallet balances...\n");

  for (const address of MY_WALLETS) {
    if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
      console.log(`⚠️ Invalid address format skipped: ${address}`);
      continue;
    }

    console.log(`👛 Wallet: ${address}`);
    for (const net of NETWORKS) {
      try {
        const balance = await getNativeBalance(net.rpc, address);
        console.log(`   - ${net.name}: ${balance} ${net.symbol}`);
      } catch (err) {
        console.log(`   - ${net.name}: Could not fetch balance`);
      }
    }
    console.log("");
  }
}

checkWalletsWhenOnline();
}
</script>
