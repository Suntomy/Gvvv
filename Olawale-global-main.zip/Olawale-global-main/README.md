# Global Pilgrim — Secure Payout Service

This folder is the **only** component allowed to move real money. The console
(`../index.html`) is a static single file: a determined user can edit its
JavaScript in DevTools. So the console records *authorisations* and this service
performs the *execution*.

## Why payouts cannot run in the frontend

> "never process payouts in frontend HTML/JavaScript. A user could manipulate
> browser code to drain your funds. All balance checks, database locks and API
> calls must happen on a secure backend server."

Every guard below exists for that reason:

| Guard | Where |
|---|---|
| Provider secret keys never reach the browser | `.env`, server only |
| Bearer-token operator auth (timing-safe compare) | `requireAuth` |
| `SELECT … FOR UPDATE` wallet row lock | `POST /api/withdrawals` |
| Balance check + debit in one transaction | same handler |
| Idempotency key (no double spend on retry) | `withdrawals.idempotency_key` |
| Compensating credit if the provider fails | catch block after commit |
| Signed webhook reconciliation | `/api/webhooks/flutterwave` |
| Rate limiting + Helmet headers | top of `server.js` |

## Install

```bash
cd server
cp .env.example .env          # fill in keys
npm install
npm run migrate               # applies schema.sql
npm start                     # http://localhost:8787
```

Create the owner wallet once:

```sql
INSERT INTO wallets (owner, currency, balance) VALUES ('olawale', 'USD', 0);
```

## Rails wired in this build

| Rail | Provider | Endpoint used |
|---|---|---|
| `bank` | Flutterwave | `GET /v3/banks/:country`, `POST /v3/accounts/resolve`, `POST /v3/transfers` |
| `swift` | Wise | `POST /v1/transfers` |
| `crypto` | ethers.js + RPC | `wallet.sendTransaction` / ERC-20 `transfer` |
| `paypal` | PayPal Payouts | `POST /v1/oauth2/token`, `POST /v1/payments/payouts` |
| `giftcard` | Reloadly | `POST /giftcards/orders` |
| `bills` | VTpass | `POST /api/pay` |
| `sim` | VTpass | `POST /api/pay` |

Paystack (`GET /bank`, `POST /transferrecipient`, `POST /transfer`) and Monnify
follow the same adapter shape — add a function next to `flutterwaveTransfer`
and a `case` in `executePayout`.

## API

All routes except `/api/health` and the webhooks require
`Authorization: Bearer $ADMIN_API_TOKEN`.

```
GET  /api/banks?country=NG
POST /api/verify-account      { account_number, bank_code }
GET  /api/wallets/:owner
GET  /api/withdrawals
POST /api/withdrawals         { owner, rail, amount, currency, account_number,
                                account_name, receiver_name, bank_code,
                                network, narration, idempotency_key }
```

`POST /api/withdrawals` returns `201` with the withdrawal row, `409
insufficient_funds`, or `502 provider_failed` **with the funds already reversed**.

## Compliance notes

* Payout aggregation requires KYB with each provider. Do not switch
  `PAYPAL_MODE=live` or use live Flutterwave keys until onboarding is complete.
* Crypto custody keys belong in a KMS/HSM. `CUSTODY_PRIVATE_KEY` is a
  development convenience only.
* Keep `ADMIN_API_TOKEN` server-side; the console backend should mint short-lived
  operator tokens rather than shipping this value to a browser.
* Enable 2FA/OTP on the operator account and log every authorisation.

## v4.1 — Module integrity & signed webhooks

Two hardening modules were added. Both are **ported from the supplied Python
reference code with the security logic corrected** — the original snippets
logged "hash match / deployment unblock" on a mismatch, and "valid signature /
credit rejected" on the rejection path. Those messages were inverted; the
behaviour here is the correct one.

### 1. Module integrity verifier — `integrity.js`

Computes SHA-256 over each guarded module and compares it to
`module-hashes.json`. A mismatch marks the module `TAMPERED` and, in
production, the process exits instead of serving modified code.

```bash
npm run integrity            # APPROVED / REJECTED per module
npm run integrity:generate   # rewrite the allowlist after a reviewed change
```

Guarded files: `server.js`, `webhooks.js`, `integrity.js`, `schema.sql`.
Set `REQUIRE_INTEGRITY=true` (default in production) to make a failure fatal.

### 2. Signed webhook credit processor — `webhooks.js`

`POST /api/webhooks/credit/:gateway` accepts an HMAC-SHA256 signature in
`X-GP-Signature` (hex, optional `sha256=` prefix), computed over the **raw**
request body. The raw bytes are captured by the `express.json({ verify })`
hook, so re-serialising the JSON can never break a signature.

```js
const sig = crypto.createHmac('sha256', process.env.GATEWAY_WEBHOOK_SECRET)
  .update(rawBody).digest('hex');
```

| Condition | Result |
|---|---|
| bad / missing signature | `401`, nothing touched, warning logged |
| unknown account number | `404`, nothing credited |
| amount ≤ 0, NaN, Infinity | `400`, nothing credited |
| duplicate `(gateway, reference)` | `200` idempotent replay, no second credit |
| valid | `200`, wallet credited inside `BEGIN … COMMIT` with `FOR UPDATE` |

Money is `NUMERIC(20,8)` in PostgreSQL and is added with `$1::numeric`, never
with a JavaScript float. The `webhook_events` table's unique
`(gateway, reference)` key is the idempotency lock.

Operator endpoints (bearer token): `GET /api/security/integrity`,
`GET /api/security/webhook-events`.

### New environment variables

```
GATEWAY_WEBHOOK_SECRET=<openssl rand -hex 32>
# GATEWAY_WEBHOOK_SECRET_FLUTTERWAVE=...   (per-gateway override)
REQUIRE_INTEGRITY=true
```

Run `npm run migrate` again — it adds the `accounts` and `webhook_events`
tables.
