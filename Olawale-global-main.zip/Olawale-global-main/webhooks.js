/*
 * Global Pilgrim — Signed Webhook Credit Processor
 * ------------------------------------------------
 * Ported from the supplied Python module (hmac + hashlib + Decimal), with the
 * security logic CORRECTED. The original snippet logged
 *   "SECURITY ALERT: valid webhook signature. Credit rejected."
 * on the rejection path and "VALIDATION: valid account or amount" on invalid
 * input — both inverted. Here:
 *
 *   signature valid   -> proceed
 *   signature invalid -> 401, nothing touched, alert raised
 *   account unknown   -> 404, nothing touched
 *   amount <= 0       -> 400, nothing touched
 *   duplicate event   -> 200 idempotent replay, no second credit
 *
 * Money is handled as NUMERIC(20,8) in PostgreSQL, never as a JS float. The
 * credit runs inside BEGIN ... COMMIT with SELECT ... FOR UPDATE on the wallet
 * row, so two concurrent callbacks can never double-credit an account.
 */

'use strict';

const crypto = require('crypto');

/* Node's equivalent of Python's hmac.compare_digest: constant-time compare. */
function safeEqualHex(a, b) {
  const ba = Buffer.from(String(a || ''), 'utf8');
  const bb = Buffer.from(String(b || ''), 'utf8');
  if (ba.length !== bb.length || ba.length === 0) return false;
  return crypto.timingSafeEqual(ba, bb);
}

/**
 * Verify an HMAC-SHA256 signature over the raw request body.
 * Accepts the digest with or without a "sha256=" prefix, and accepts a
 * comma-separated signature header (Stripe-style) by checking each candidate.
 */
function verifyGatewaySignature(rawBody, headerValue, secret) {
  if (!secret || !headerValue) return false;
  const body = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody || ''), 'utf8');
  const expected = crypto.createHmac('sha256', secret).update(body).digest('hex');

  const candidates = String(headerValue)
    .split(',')
    .map(s => s.trim().replace(/^sha256=/i, '').toLowerCase())
    .filter(Boolean);

  return candidates.some(c => safeEqualHex(c, expected));
}

function signPayload(rawBody, secret) {
  const body = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody || ''), 'utf8');
  return crypto.createHmac('sha256', secret).update(body).digest('hex');
}

function payloadHash(rawBody) {
  const body = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody || ''), 'utf8');
  return crypto.createHash('sha256').update(body).digest('hex');
}

/** Money validation that rejects NaN, Infinity, negatives and absurd values. */
function normaliseAmount(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  if (n > 1e12) return null;
  const rounded = Math.round((n + Number.EPSILON) * 1e8) / 1e8;
  if (!(rounded > 0)) return null;
  return rounded.toFixed(8);
}

/**
 * Credit a verified inbound payment.
 *
 * @param {object} deps  { pool, onCredit }
 * @returns {Promise<{ok:boolean, code:string, status:number}>}
 */
async function processVerifiedCredit(deps, input) {
  const { pool, onCredit } = deps;
  const {
    gateway,
    reference,
    accountNumber,
    amount,
    currency = 'USD',
    senderName = '',
    narration = '',
    rawBody
  } = input || {};

  if (!gateway || !reference || !accountNumber) {
    return { ok: false, code: 'MISSING_FIELDS', status: 400, message: 'gateway, reference and accountNumber are required' };
  }

  const amountText = normaliseAmount(amount);
  if (!amountText) {
    return { ok: false, code: 'INVALID_AMOUNT', status: 400, message: 'amount must be a positive finite number' };
  }

  const hash = payloadHash(rawBody || '');

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    /* Idempotency: the unique reference is the lock. A replayed callback
       inserts nothing, so it can never credit twice. */
    const claim = await client.query(
      `INSERT INTO webhook_events (gateway, reference, payload_hash, status)
       VALUES ($1,$2,$3,'RECEIVED')
       ON CONFLICT (gateway, reference) DO NOTHING
       RETURNING id`,
      [gateway, reference, hash]
    );

    if (claim.rows.length === 0) {
      await client.query('ROLLBACK');
      return { ok: true, code: 'DUPLICATE', status: 200, duplicate: true, reference, message: 'event already processed' };
    }

    const eventId = claim.rows[0].id;

    const wallet = await client.query(
      `SELECT w.id, w.owner, w.balance
         FROM wallets w
         JOIN accounts a ON a.owner = w.owner
        WHERE a.account_number = $1 AND w.currency = $2
        FOR UPDATE OF w`,
      [accountNumber, currency]
    );

    if (wallet.rows.length === 0) {
      await client.query(
        `UPDATE webhook_events SET status = 'REJECTED', reason = 'unknown account', processed_at = now() WHERE id = $1`,
        [eventId]
      );
      await client.query('COMMIT');
      return { ok: false, code: 'UNKNOWN_ACCOUNT', status: 404, reference, message: 'no wallet for that account number' };
    }

    const row = wallet.rows[0];
    const updated = await client.query(
      `UPDATE wallets SET balance = balance + $1::numeric, updated_at = now()
        WHERE id = $2 RETURNING balance`,
      [amountText, row.id]
    );

    await client.query(
      `INSERT INTO ledger (reference, wallet_id, direction, amount, kind, note)
       VALUES ($1,$2,'CREDIT',$3::numeric,'INBOUND',$4)`,
      [reference, row.id, amountText, `${gateway} inbound credit`]
    );

    await client.query(
      `UPDATE webhook_events SET status = 'CREDITED', wallet_id = $1, processed_at = now() WHERE id = $2`,
      [row.id, eventId]
    );

    await client.query('COMMIT');

    const result = {
      ok: true,
      code: 'CREDITED',
      status: 200,
      reference,
      accountNumber,
      owner: row.owner,
      amount: amountText,
      currency,
      balance: updated.rows[0].balance,
      senderName,
      narration
    };

    if (typeof onCredit === 'function') {
      try { onCredit(result); } catch (e) { console.error('credit alert failed', e.message); }
    }
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = {
  safeEqualHex,
  verifyGatewaySignature,
  signPayload,
  payloadHash,
  normaliseAmount,
  processVerifiedCredit
};
