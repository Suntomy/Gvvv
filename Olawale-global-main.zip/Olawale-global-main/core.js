/* ============================================================
   GLOBAL PILGRIM — CORE
   State, storage, authentication, navigation, ledger posting.
   Append-only: nothing in this file deletes a record.
   ============================================================ */
'use strict';

const LS_KEY = 'gp_engine_v3';
const SESSION_KEY = 'gp_session_v3';
const BUILD = 'v4.2.0';
const SESSION_MINUTES = 20;

let S = null;
let session = null;
let sessionTimer = null;
let loginRole = 'admin';
let READONLY = false;

/* ---------------- deployment seal ----------------
   A sealed deployment is read-only: no posting, no state change.
   Activated by the #sealed link or the Settings seal switch. */
function ro() {
  if (READONLY) { toast('This deployment is sealed — read-only. No records can be changed.', 'er'); return true; }
  return false;
}
function setReadOnly(on, persist) {
  READONLY = !!on;
  document.body.classList.toggle('sealed', READONLY);
  let b = document.getElementById('sealBar');
  if (READONLY) {
    if (!b) {
      b = document.createElement('div');
      b.id = 'sealBar';
      b.className = 'seal-bar';
      b.innerHTML = 'READ-ONLY DEPLOYMENT &middot; records are append-only and locked on this link';
      document.body.appendChild(b);
    }
  } else if (b) b.remove();
  if (persist) { try { localStorage.setItem('gp_sealed', on ? '1' : '0'); } catch (e) {} }
}

/* ---------------- utilities ---------------- */
const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const money = n => (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const usd = n => '$' + money(n);
const pad = (n, l = 2) => String(n).padStart(l, '0');
function nowISO() { return new Date().toISOString(); }
function stamp(d) {
  const t = d ? new Date(d) : new Date();
  return t.getFullYear() + '-' + pad(t.getMonth() + 1) + '-' + pad(t.getDate()) + ' ' +
    pad(t.getHours()) + ':' + pad(t.getMinutes()) + ':' + pad(t.getSeconds());
}
function shortTime(d) { const t = new Date(d); return pad(t.getHours()) + ':' + pad(t.getMinutes()) + ':' + pad(t.getSeconds()); }
function uid(p = 'ID') { return p + '-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase(); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function hash(str) {
  let h1 = 0x811c9dc5, h2 = 0x01000193;
  for (let i = 0; i < str.length; i++) {
    h1 ^= str.charCodeAt(i); h1 = Math.imul(h1, 16777619);
    h2 = Math.imul(h2 ^ str.charCodeAt(i), 2246822519);
  }
  return ((h1 >>> 0).toString(16) + (h2 >>> 0).toString(16)).toUpperCase().padEnd(16, '0');
}
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }

/* ---------------- toast ---------------- */
function toast(msg, kind = '') {
  const box = document.getElementById('toasts');
  if (!box) return;
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(24px)'; el.style.transition = '.3s'; }, 3600);
  setTimeout(() => el.remove(), 4000);
}

/* ---------------- state ---------------- */
function seedState() {
  const now = nowISO();
  return {
    build: BUILD,
    createdAt: now,
    auth: {
      id: 'admin',
      key: 'pilgrim',
      pin: '240275',
      role: 'admin',
      fee: 0.1,
      customized: false,
      attempts: 0,
      lockedUntil: 0
    },
    settings: { autoSettle: false, requirePin: true, autoAlarm: true, lot: 250, tp: 1.2, harvest: 0.05, dirWindow: 6, profitToMain: true, continuous: true },
    wallets: {
      main: 0, trading: 0, profit: 0, micro: 0, macro: 0, cscs: 0
    },
    mining: {
      on: false, pending: 0, settled: 0, hash: 0, profitPct: 100,
      coins: [
        { sym: 'PGC', name: 'Pilgrim Coin', pool: 'pgc-native', rate: 4.2, accrued: 0, on: true },
        { sym: 'BTC', name: 'Bitcoin', pool: 'sha256', rate: 1.8, accrued: 0, on: true },
        { sym: 'ETH', name: 'Ethereum', pool: 'ethash', rate: 2.4, accrued: 0, on: true },
        { sym: 'LTC', name: 'Litecoin', pool: 'scrypt', rate: 1.1, accrued: 0, on: true },
        { sym: 'TON', name: 'Toncoin', pool: 'ton-pool', rate: 0.9, accrued: 0, on: true },
        { sym: 'USDT', name: 'Tether TRC20', pool: 'trx-pool', rate: 0.6, accrued: 0, on: false }
      ]
    },
    robot: { on: false, auto: true, autoInvest: true, autoSweep: true, startedAt: null },
    traffic: {
      on: false, tasks: 0, earned: 0, perTask: 100,
      wallet: '0x7f3a9c21D4eB8a06C5d1E92bB47aC3e08F1d2A65',
      lanes: [
        { id: 'FX-CAP', name: 'Forex Market Capital', cls: 'Capital', on: true, done: 0 },
        { id: 'CRY-CAP', name: 'Crypto Market Capital', cls: 'Crypto', on: true, done: 0 },
        { id: 'EQ-CAP', name: 'Equity Market Capital', cls: 'Equity', on: true, done: 0 },
        { id: 'MTL-CAP', name: 'Metals & Minerals Capital', cls: 'Commodity', on: true, done: 0 },
        { id: 'LIQ-ROUTE', name: 'Liquidity Delivery Route', cls: 'Routing', on: true, done: 0 }
      ]
    },
    positions: [],
    ledger: [],
    audit: [],
    clients: [],
    settlements: [],
    payouts: [],
    bank: {
      name: 'Global Pilgrim Bank',
      code: '70',
      swift: 'GPLNNGLA',
      account: '7000000013',
      office: 'Global Pilgrim House, Victoria Island, Lagos State, Nigeria',
      country: 'NG',
      licenceStatus: 'APPLICATION PENDING',
      trademarkStatus: 'FILED — NOT YET REGISTERED'
    },
    integrations: [],
    inbound: [],
    receipts: [],
    signals: [],
    alarms: [],
    cameras: [],
    nodes: [
      { id: 'N1', label: 'Ethereum Mainnet', kind: 'EVM RPC', url: 'https://ethereum-rpc.publicnode.com', chain: '1', status: 'provisioned' },
      { id: 'N2', label: 'Polygon Mainnet', kind: 'EVM RPC', url: 'https://polygon-bor-rpc.publicnode.com', chain: '137', status: 'provisioned' },
      { id: 'N3', label: 'Global Pilgrim Bank Core', kind: 'Bank API', url: '', chain: 'GPB-CORE', status: 'awaiting endpoint' },
      { id: 'N4', label: 'CSCS Settlement', kind: 'Capital Market', url: '', chain: 'CSCS', status: 'awaiting endpoint' },
      { id: 'N5', label: 'Market Data Feed', kind: 'Market API', url: 'https://api.binance.com', chain: 'FEED', status: 'provisioned' }
    ]
  };
}

function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) { S = seedState(); save(); return; }
    const parsed = JSON.parse(raw);
    S = Object.assign(seedState(), parsed);
    S.auth = Object.assign(seedState().auth, parsed.auth || {});
    S.settings = Object.assign(seedState().settings, parsed.settings || {});
    S.wallets = Object.assign(seedState().wallets, parsed.wallets || {});
    S.mining = Object.assign(seedState().mining, parsed.mining || {});
    if (!Array.isArray(S.ledger)) S.ledger = [];
    if (!Array.isArray(S.audit)) S.audit = [];
    if (!Array.isArray(S.nodes) || !S.nodes.length) S.nodes = seedState().nodes;
    S.robot = Object.assign(seedState().robot, parsed.robot || {});
    if (!Array.isArray(S.payouts)) S.payouts = [];
    if (!Array.isArray(S.integrations)) S.integrations = [];
    if (!Array.isArray(S.inbound)) S.inbound = [];
    S.bank = Object.assign(seedState().bank, parsed.bank || {});
    /* one-time correction: profit must land in the Profit Balance automatically */
    if (!parsed.v4profit) {
      S.settings.profitToMain = false;
      S.robot.autoSweep = false;
      if (S.settings.harvest == null) S.settings.harvest = 0.05;
      S.v4profit = true;
    }
    /* v4.2 — profit is always booked to the Profit Balance first, then swept
       to the Main Balance. Nothing else may receive it. */
    if (!parsed.v42profit) {
      S.settings.profitToMain = true;
      S.robot.autoSweep = true;
      S.v42profit = true;
    }
    if (S.traffic == null) S.traffic = seedState().traffic;
    if (S.mining.profitPct == null) S.mining.profitPct = 100;
  } catch (e) {
    S = seedState();
  }
}
function save() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) { console.warn('vault write failed', e); }
}

/* ---------------- audit (append-only) ---------------- */
function audit(action, detail) {
  if (READONLY) return;
  S.audit.push({
    ts: nowISO(),
    operator: session ? session.id : 'system',
    role: session ? session.role : 'engine',
    action: action,
    detail: detail || '',
    node: session ? session.node : 'CORE'
  });
  if (S.audit.length > 4000) S.audit.splice(0, S.audit.length - 4000);
  save();
  const c = document.getElementById('auditCount');
  if (c) c.textContent = S.audit.length;
}

/* ---------------- ledger posting ---------------- */
function post(opts) {
  if (READONLY) return null;
  const { type, from, to, amount, note, status } = opts;
  const amt = r2(amount);
  if (!(amt > 0)) return null;
  if (from && S.wallets[from] != null) S.wallets[from] = r2(S.wallets[from] - amt);
  if (to && S.wallets[to] != null) S.wallets[to] = r2(S.wallets[to] + amt);
  const entry = {
    ts: nowISO(),
    ref: uid('GP'),
    type: type,
    from: from || 'EXTERNAL',
    to: to || 'EXTERNAL',
    amount: amt,
    status: status || 'COMPLETED',
    note: note || ''
  };
  S.ledger.push(entry);
  if (S.ledger.length > 3000) S.ledger.splice(0, S.ledger.length - 3000);
  save();
  return entry;
}

function totalEquity() {
  const w = S.wallets;
  return r2(w.main + w.trading + w.profit + w.micro + w.macro + w.cscs + (S.mining.pending || 0));
}

/* ---------------- authentication ---------------- */
function setLoginRole(role) {
  loginRole = role;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.role === role));
  const idField = document.getElementById('loginId');
  idField.placeholder = role === 'admin' ? 'Enter operator identifier' : 'Enter account number';
  hideAuth();
}
function hideAuth() { const m = document.getElementById('authMsg'); m.className = 'auth-msg'; m.textContent = ''; }
function showAuth(msg, ok) {
  const m = document.getElementById('authMsg');
  m.textContent = msg;
  m.className = 'auth-msg show' + (ok ? ' ok' : '');
}
function togglePw() {
  const f = document.getElementById('loginKey');
  const b = document.querySelector('.pw-toggle');
  const show = f.type === 'password';
  f.type = show ? 'text' : 'password';
  b.textContent = show ? 'Hide' : 'Show';
}
function focusLogin() {
  const el = document.getElementById('loginId');
  if (el) { el.focus(); document.getElementById('loginShell').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
}
function scrollToId(id) { const el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: 'smooth' }); }

function handleLogin(e) {
  e.preventDefault();
  const id = document.getElementById('loginId').value.trim();
  const key = document.getElementById('loginKey').value;
  const pin = document.getElementById('loginPin').value.trim();
  const node = document.getElementById('loginNode').value;
  const btn = document.getElementById('loginBtn');

  if (Date.now() < (S.auth.lockedUntil || 0)) {
    const mins = Math.ceil((S.auth.lockedUntil - Date.now()) / 60000);
    showAuth('Access suspended after repeated failures. Try again in ' + mins + ' minute(s) or contact the proprietor.');
    return;
  }
  if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
    showAuth('Security PIN must be exactly six digits.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Verifying…';

  setTimeout(() => {
    let ok = false, who = '', role = loginRole, label = '';

    if (loginRole === 'admin') {
      ok = id.toLowerCase() === String(S.auth.id).toLowerCase() && key === S.auth.key && pin === S.auth.pin;
      who = S.auth.id;
      label = 'Administrator';
    } else {
      const c = S.clients.find(x => x.account === id);
      if (c && c.key === key && c.pin === pin) {
        if (c.status !== 'ACTIVE') { showAuth('This account is ' + c.status + '. Contact the administrator.'); btn.disabled = false; btn.textContent = 'Authenticate & Open Console'; return; }
        ok = true; who = c.account; label = c.holder;
        c.lastSeen = nowISO(); c.lastNode = node;
        save();
      }
    }

    if (!ok) {
      S.auth.attempts = (S.auth.attempts || 0) + 1;
      if (S.auth.attempts >= 5) { S.auth.lockedUntil = Date.now() + 5 * 60000; S.auth.attempts = 0; }
      save();
      showAuth('Authentication failed. Credentials rejected by the engine.');
      btn.disabled = false;
      btn.textContent = 'Authenticate & Open Console';
      return;
    }

    S.auth.attempts = 0; S.auth.lockedUntil = 0; save();
    startSession(who, role, node, label);
    btn.disabled = false;
    btn.textContent = 'Authenticate & Open Console';
    hideAuth();
  }, 550);
}

function startSession(id, role, node, label) {
  session = { id, role, node, label, start: Date.now(), exp: Date.now() + SESSION_MINUTES * 60000 };
  try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(session)); } catch (e) {}
  document.getElementById('cover').style.display = 'none';
  document.getElementById('app').classList.add('on');
  document.getElementById('sideWho').textContent = label || id;
  document.getElementById('sideRole').textContent = role === 'admin' ? 'Full Custody Access' : 'Client Access';
  document.getElementById('sSession').textContent = node;
  audit('SESSION_OPEN', 'Operator ' + id + ' authenticated at node ' + node);
  const isAdmin = role === 'admin';
  document.body.classList.toggle('client-mode', !isAdmin);
  document.querySelectorAll('.nav-item').forEach(n => {
    const adminOnly = ['payouts', 'network', 'nodes', 'settings', 'audit', 'overview', 'trading', 'mining', 'traffic', 'wallets', 'bank', 'integrations'].includes(n.dataset.view);
    n.style.display = (!isAdmin && adminOnly) ? 'none' : '';
  });
  renderAll();
  startEngines();
  resetSessionTimer();
  const cn = document.querySelector('.nav-item[data-view="clients"]');
  if (cn) { const t = cn.lastChild; if (t && t.nodeType === 3) t.nodeValue = ' My Account '; }
  if (!isAdmin) go('clients');
}

function lockConsole() {
  if (session) audit('SESSION_LOCK', 'Console locked by ' + session.id);
  stopEngines();
  session = null;
  try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
  document.getElementById('app').classList.remove('on');
  document.body.classList.remove('client-mode');
  document.querySelectorAll('.nav-item').forEach(n => { n.style.display = ''; });
  document.getElementById('cover').style.display = '';
  document.getElementById('loginKey').value = '';
  document.getElementById('loginPin').value = '';
  showAuth('Console locked. Session terminated.', true);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetSessionTimer() {
  clearTimeout(sessionTimer);
  sessionTimer = setTimeout(() => { if (session) { toast('Session expired — console locked.', 'er'); lockConsole(); } }, SESSION_MINUTES * 60000);
}

function showRecovery() {
  showAuth('Access recovery is handled directly by the proprietor: globalpilgrimautonomous@gmail.com / +2349030277275. Credentials are never transmitted through this page.', true);
}

/* ---------------- navigation ---------------- */
/* ---------------- Global Pilgrim account numbers ---------------- */
/* Ten digits, Global Pilgrim bank code 70, like a domestic NUBAN. The last
   digit is a Luhn-style check digit so a mistyped number is rejected locally. */
function gpCheckDigit(digits) {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = Number(digits[digits.length - 1 - i]);
    if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return String((10 - (sum % 10)) % 10);
}
function gpAccountNo() {
  const used = new Set((S.clients || []).map(c => c.account));
  for (let attempt = 0; attempt < 500; attempt++) {
    let body = '70';
    for (let i = 0; i < 7; i++) body += Math.floor(Math.random() * 10);
    const full = body + gpCheckDigit(body);
    if (!used.has(full)) return full;
  }
  return '70' + String(Date.now()).slice(-8);
}
function validGpAccount(no) {
  const s = String(no || '').trim();
  if (!/^\d{10}$/.test(s)) return false;
  return gpCheckDigit(s.slice(0, 9)) === s.slice(9);
}

const VIEW_META = {
  overview: ['Overview', 'Engine health and consolidated position'],
  trading: ['Trading Terminal', 'Live execution across all markets'],
  mining: ['Mining Engine', 'Continuous multi-coin credit accrual at 100% profit'],
  traffic: ['Cloud Traffic', 'Autonomous market-capital delivery lanes'],
  wallets: ['Wallets & Balances', 'Internal ledger custody'],
  bank: ['External Bank', 'Global settlement and receipts'],
  payouts: ['Payout Rails', 'Aggregator withdrawals across every rail'],
  terminal: ['Trading Floor', 'Live account, live earnings, public terminal'],
  integrations: ['Payment Integrations', 'Provider health scan and registry'],
  clients: ['Client Accounts', 'Account register and access control'],
  network: ['Network Terminal', 'Surveillance, signals and camera mesh'],
  nodes: ['Node & API Links', 'Endpoints, protocols and payment links'],
  settings: ['Settings', 'Credentials, defaults and custody'],
  audit: ['Audit Trail', 'Immutable operator record']
};

function go(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('on'));
  const el = document.getElementById('view-' + view);
  if (el) el.classList.add('on');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === view));
  const meta = VIEW_META[view] || ['Console', ''];
  document.getElementById('tbTitle').childNodes[0].nodeValue = meta[0];
  document.getElementById('tbSub').textContent = meta[1];
  document.querySelector('main').scrollTop = 0;
  renderView(view);
  if (view === 'network' && typeof drawRadar === 'function') drawRadar();
}

/* ---------------- modal ---------------- */
function openModal(title, fields, onSubmit) {
  const ov = document.createElement('div');
  ov.className = 'modal-ov';
  const rows = fields.map((f, i) => {
    const input = f.type === 'select'
      ? `<select class="inp" id="mf_${i}">${f.options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('')}</select>`
      : `<input class="inp" id="mf_${i}" type="${f.type || 'text'}" placeholder="${esc(f.placeholder || '')}" value="${esc(f.value || '')}" ${f.step ? 'step="' + f.step + '"' : ''}>`;
    return `<div><label class="flabel">${esc(f.label)}</label>${input}</div>`;
  }).join('');
  ov.innerHTML = `<div class="modal">
    <div class="modal-h"><h3>${esc(title)}</h3><button class="modal-x" type="button">&times;</button></div>
    <div class="form-grid" style="margin:16px 0">${rows}</div>
    <div style="display:flex;gap:8px">
      <button class="btn-sm" style="flex:1" data-cancel>Cancel</button>
      <button class="btn-sm gold" style="flex:1" data-ok>Confirm</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const close = () => ov.remove();
  ov.querySelector('.modal-x').onclick = close;
  ov.querySelector('[data-cancel]').onclick = close;
  ov.onclick = e => { if (e.target === ov) close(); };
  ov.querySelector('[data-ok]').onclick = () => {
    const vals = fields.map((f, i) => document.getElementById('mf_' + i).value.trim());
    if (fields.some((f, i) => f.required !== false && !vals[i])) { toast('All fields are required.', 'er'); return; }
    close();
    onSubmit(vals);
  };
  const first = ov.querySelector('input,select');
  if (first) setTimeout(() => first.focus(), 60);
}
