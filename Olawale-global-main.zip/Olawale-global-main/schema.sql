-- Global Pilgrim payout service schema (PostgreSQL 14+)
-- The wallet row is the single source of truth for spendable balance.
-- Every withdrawal takes a row lock (SELECT ... FOR UPDATE) so two requests
-- can never spend the same funds, even if they arrive in the same millisecond.

CREATE TABLE IF NOT EXISTS wallets (
  id           BIGSERIAL PRIMARY KEY,
  owner        TEXT        NOT NULL,
  currency     TEXT        NOT NULL DEFAULT 'USD',
  balance      NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (balance >= 0),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner, currency)
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id             BIGSERIAL PRIMARY KEY,
  reference      TEXT        NOT NULL UNIQUE,
  idempotency_key TEXT       UNIQUE,
  owner          TEXT        NOT NULL,
  rail           TEXT        NOT NULL,
  provider       TEXT        NOT NULL,
  currency       TEXT        NOT NULL DEFAULT 'USD',
  amount         NUMERIC(20,8) NOT NULL CHECK (amount > 0),
  fee            NUMERIC(20,8) NOT NULL DEFAULT 0,
  account_number TEXT        NOT NULL,
  account_name   TEXT        NOT NULL,
  receiver_name  TEXT        NOT NULL,
  bank_code      TEXT,
  bank_name      TEXT,
  network        TEXT,
  narration      TEXT,
  status         TEXT        NOT NULL DEFAULT 'PENDING',
  provider_ref   TEXT,
  failure_reason TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ledger (
  id           BIGSERIAL PRIMARY KEY,
  reference    TEXT        NOT NULL,
  wallet_id    BIGINT      NOT NULL REFERENCES wallets(id),
  direction    TEXT        NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
  amount       NUMERIC(20,8) NOT NULL CHECK (amount > 0),
  kind         TEXT        NOT NULL,
  note         TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_owner ON withdrawals(owner, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ledger_wallet ON ledger(wallet_id, created_at DESC);

-- ------------------------------------------------------------------
-- v4.1 — signed inbound webhooks + account registry
-- ------------------------------------------------------------------

-- Maps a 10-digit Global Pilgrim account number to a wallet owner.
-- The console generates these numbers; the backend is the authority.
CREATE TABLE IF NOT EXISTS accounts (
  account_number TEXT PRIMARY KEY CHECK (account_number ~ '^[0-9]{10}$'),
  owner          TEXT NOT NULL,
  account_name   TEXT NOT NULL,
  bank_code      TEXT NOT NULL DEFAULT '70',
  bank_name      TEXT NOT NULL DEFAULT 'Global Pilgrim Bank',
  currency       TEXT NOT NULL DEFAULT 'USD',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner)
);

-- Every accepted webhook is recorded exactly once. The (gateway, reference)
-- unique key is what makes a replayed callback a no-op instead of a double credit.
CREATE TABLE IF NOT EXISTS webhook_events (
  id           BIGSERIAL PRIMARY KEY,
  gateway      TEXT NOT NULL,
  reference    TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'RECEIVED',
  reason       TEXT,
  wallet_id    BIGINT REFERENCES wallets(id),
  received_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  UNIQUE (gateway, reference)
);

CREATE INDEX IF NOT EXISTS idx_webhook_events_recent ON webhook_events(received_at DESC);
